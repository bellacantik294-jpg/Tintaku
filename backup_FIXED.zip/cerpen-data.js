window.SAMPLE_CERPEN = [
  {
    id: "c1",
    title: "Langit Senja",
    category: "Romantis",
    date: "2025-11-24",
    summary: "Sepotong senja yang menyimpan seribu cerita.",
    cover: "",
    content: `
      <p>Di tepian kota, senja turun perlahan seperti seseorang yang sedang rindu...</p>
      <p>Warna oranye yang lembut menyapu langit, memantulkan perasaan yang tidak pernah sempat terucap.</p>
    `
  }
];
